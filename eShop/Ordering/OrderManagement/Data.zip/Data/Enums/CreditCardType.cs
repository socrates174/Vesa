﻿namespace eShop.Ordering.OrderManagement.Data.Enums
{
    public enum CreditCardType
    {
        AmericanExpress,
        Mastercard,
        Visa
    }
}
