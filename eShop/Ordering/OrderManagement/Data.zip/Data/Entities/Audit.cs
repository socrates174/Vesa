﻿using IoCloud.Shared.Entity.Infrastructure;

namespace eShop.Ordering.OrderManagement.Data.Entities
{
    public class Audit : NoSqlAudit
    {
        public Audit() : base()
        {
        }
    }
}
