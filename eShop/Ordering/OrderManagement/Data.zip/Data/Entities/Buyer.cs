﻿namespace eShop.Ordering.OrderManagement.Data.Entities
{
    public class Buyer
    {
        public string Name { get; set; }
        public string EmailAddress { get; set; }
    }
}
