﻿namespace eShop.Ordering.OrderManagement.Data.Entities
{
    public class Product
    {
        public string SKU { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
    }
}
